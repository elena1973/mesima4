import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FamilyTasksService } from '../familyTasks.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  public newTask;
  constructor(public FT:FamilyTasksService) { }

  ngOnInit() {
    this.newTask=new FormGroup({
      description: new FormControl,
      family: new FormControl
    })
  }
  onSubmit(){
    console.log(this.newTask.value);
    this.FT.addToDoList(this.newTask.value).subscribe(

    )
  }
}
