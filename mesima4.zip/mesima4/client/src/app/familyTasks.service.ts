import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FamilyTasksService {

  constructor(public http:HttpClient) { }

  public getFamilyMembers(){
    return this.http.get('http://localhost:4000/family');
  }
  public getToDoList(){
    return this.http.get('http://localhost:4000/task');
  }
  public addToDoList(newTask:any){
    return this.http.post('http://localhost:4000/addTasks',newTask);
  }

}
