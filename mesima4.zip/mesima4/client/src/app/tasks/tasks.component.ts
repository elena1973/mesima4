import { Component, OnInit } from '@angular/core';
import { FamilyTasksService } from '../familyTasks.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {

  constructor(public FT:FamilyTasksService) { }
  public Tasks;
  ngOnInit() {
    this.FT.getToDoList().subscribe(
      res=>{console.log(res)
          this.Tasks=res;
          
      },
      err=>console.log(err)
    )
  }

}