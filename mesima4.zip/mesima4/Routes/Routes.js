const express = require('express');
const mysql = require('mysql');


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'FamilyTasks'
});
connection.connect(err => {
    if (err) {
        throw err;
    } else {
        console.log('Connected to FamilyTasks DB...')
    }
});


const router = express.Router();

router.get('/familyr', (req, res) => {
    const SELECT_FAMILY = 'SELECT * FROM `familyr`';
    connection.query(SELECT_FAMILY, (err, result) => {
        if (err) {
            return res.send(err);
        } else {
            return res.json(result);
        }
    })
});

router.post('/addTask', (req, res) => {
            let description = req.body.description;
            let familyr = req.body.familyr;
            if (familyr==="genadi"){
                familyr=1;
            }
            else if (familyr==="elena"){
                familyr=2;
            }
            else{
                familyr=3;
            }
            else{familyr=4}
            
            var now= new Date();
            var dd = String(now.getDate()).padStart(2, '0');
            var mm = String(now.getMonth() + 1).padStart(2, '0');
            var yyyy = now.getYear();
            now =yyyy+mm+dd;

            console.log(description);
            console.log(now);
            console.log(familyr);

            
            const NEW_TASK=`INSERT INTO tasks(Description, Date, BelongsTo) VALUES ('${description}',${now},${familyMember})`;

            connection.query(NEW_TASK, (err, result) => {
                if (err) {
                    throw err;
                } else {
                    return res.json(result);
                }
                
            });
           
});


        router.get('/tasks', (req, res) => {
            const SELECT_TASKS = 'SELECT * FROM `tasks` INNER JOIN `familyr` ON tasks.Belongsto = familyr.ID';
            connection.query(SELECT_TASKS, (err, result) => {
                if (err) {
                    return res.send(err);
                } else {
                    return res.json(result);
                }
            })
        });

        module.exports = router;